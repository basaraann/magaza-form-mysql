/****************************************************************************
**					SAKARYA �N�VERS�TES�
**				B�LG�SAYAR VE B�L���M B�L�MLER� FAK�LTES�
**				    B�LG�SAYAR M�HEND�SL��� B�L�M�
**				   NESNEYE DAYALI PROGRAMLAMA DERS�
**					2014-2015 BAHAR D�NEM�
**	
**				�DEV NUMARASI..........:Proje
**				��RENC� ADI............:Bu�ra Ba�aran
**				��RENC� NUMARASI.......:g211210015
**                         DERS�N ALINDI�I GRUP...:
****************************************************************************/


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace proje
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection baglanti = new SqlConnection("Data Source=DESKTOP-7QP2GE5;Initial Catalog=Stok_Takip;Integrated Security=True");
        DataSet daset = new DataSet();
        private void sepetlistele()
        {
            baglanti.Open();
            SqlDataAdapter adtr = new SqlDataAdapter("select *from sepet", baglanti);
            adtr.Fill(daset,"sepet");
            dataGridView1.DataSource = daset.Tables["sepet"];
            dataGridView1.Columns[0].Visible = false;
            dataGridView1.Columns[1].Visible = false;
            dataGridView1.Columns[2].Visible = false;
            baglanti.Close();
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            sepetlistele();
        }
        private void hesapla()
        {
            try
            {
                baglanti.Open();
                SqlCommand komut = new SqlCommand("select sum(toplamFiyat) from sepet", baglanti);
                lblGenelToplam.Text = komut.ExecuteScalar() + "TL";
                baglanti.Close();
            }
            catch(Exception)
            {
                ;
            }
        }
        private void button4_Click(object sender, EventArgs e)
        {
            for(int i=0;i<dataGridView1.Rows.Count-1;i++)
            {         
                baglanti.Open();
                SqlCommand komut = new SqlCommand("insert into satis(tc,adsoyad,telefon,barkodNo,urunAdi,miktari,satisFiyati,toplamFiyat,tarih) values(@tc,@adsoyad,@telefon,@barkodNo,@urunAdi,@miktari,@satisFiyati,@toplamFiyat,@tarih)", baglanti);
                komut.Parameters.AddWithValue("@tc", txtTc.Text);
                komut.Parameters.AddWithValue("@adsoyad", txtAdSoyad.Text);
                komut.Parameters.AddWithValue("@telefon", txtTelefon.Text);
                komut.Parameters.AddWithValue("@barkodNo", dataGridView1.Rows[i].Cells["barkodNo"].Value.ToString());//ka� sat�r varsa onu barkod no ya aktar.
                komut.Parameters.AddWithValue("@urunAdi", dataGridView1.Rows[i].Cells["urunAdi"].Value.ToString());
                komut.Parameters.AddWithValue("@miktari", int.Parse(dataGridView1.Rows[i].Cells["miktari"].Value.ToString()));
                komut.Parameters.AddWithValue("@satisFiyati", double.Parse(dataGridView1.Rows[i].Cells["satisFiyati"].Value.ToString()));
                komut.Parameters.AddWithValue("@toplamFiyat", double.Parse(dataGridView1.Rows[i].Cells["toplamFiyat"].Value.ToString()));
                komut.Parameters.AddWithValue("@tarih", DateTime.Now.ToString());
                komut.ExecuteNonQuery();         
                SqlCommand komut2 = new SqlCommand("update urun set miktari=miktari-'" + int.Parse(dataGridView1.Rows[i].Cells["miktari"].Value.ToString()) + "' where barkodNo='" + dataGridView1.Rows[i].Cells["barkodNo"].Value.ToString() + "'", baglanti);
                komut2.ExecuteNonQuery();
                baglanti.Close();
            }
            baglanti.Open();
            SqlCommand komut3 = new SqlCommand("delete from sepet", baglanti);
            komut3.ExecuteNonQuery();
            baglanti.Close();
            daset.Tables["sepet"].Clear();
            sepetlistele();
            hesapla();

        }

        private void button5_Click(object sender, EventArgs e)
        {
            FrmM�steriEkle ekle = new FrmM�steriEkle();
            ekle.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            FrmM��teriListele listele = new FrmM��teriListele();
            listele.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FrmKategorics kategori=new FrmKategorics();
            kategori.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FrmMarka marka = new FrmMarka();
            marka.ShowDialog();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Frm�r�nEkle ekle = new Frm�r�nEkle();
            ekle.ShowDialog();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Frm�r�nListele listeleme = new Frm�r�nListele();
            listeleme.ShowDialog();
        }

        private void txtTc_TextChanged(object sender, EventArgs e)
        {
            if (txtTc.Text == "")
            {
                txtAdSoyad.Text = "";
                txtTelefon.Text = "";
            }
            baglanti.Open();
            SqlCommand komut = new SqlCommand("select *from m��teri where tc like '"+txtTc.Text+"'", baglanti);
            SqlDataReader read = komut.ExecuteReader();
            while(read.Read())
            {
                txtAdSoyad.Text = read["adsoyad"].ToString();
                txtTelefon.Text = read["telefon"].ToString();
            }
            baglanti.Close();
        }

        private void txtBarkodNo_TextChanged(object sender, EventArgs e)
        {
            Temizle();
            baglanti.Open();
            SqlCommand komut = new SqlCommand("select *from urun where barkodNo like '" + txtBarkodNo.Text + "'", baglanti);
            SqlDataReader read = komut.ExecuteReader();
            while (read.Read())
            {
                txt�r�nAd�.Text = read["urunAdi"].ToString();
                txtSat��Fiyat�.Text = read["SatisFiyati"].ToString();

            }
            baglanti.Close();
        }

        private void Temizle()
        {
            if (txtBarkodNo.Text == "")
            {
                foreach (Control item in groupBox2.Controls)
                {
                    if (item is TextBox)
                    {
                        if (item != txtMiktar�)
                        {
                            item.Text = "";
                        }
                    }
                }
            }
        }
        bool durum;
        private void barkodKontrol()
        {
            durum = true;
            baglanti.Open();
            SqlCommand komut = new SqlCommand("select *from sepet", baglanti);
            SqlDataReader read = komut.ExecuteReader();
            while(read.Read())
            {
                if(txtBarkodNo.Text==read["barkodNo"].ToString())
                {
                    durum = false;
                }
            }
            baglanti.Close();
        }

        private void btnEkle_Click(object sender, EventArgs e)
        {
            barkodKontrol();
            if (durum == true)
            {
                baglanti.Open();
                SqlCommand komut = new SqlCommand("insert into sepet(tc,adsoyad,telefon,barkodNo,urunAdi,miktari,satisFiyati,toplamFiyat,tarih) values(@tc,@adsoyad,@telefon,@barkodNo,@urunAdi,@miktari,@satisFiyati,@toplamFiyat,@tarih)", baglanti);
                komut.Parameters.AddWithValue("@tc", txtTc.Text);
                komut.Parameters.AddWithValue("@adsoyad", txtAdSoyad.Text);
                komut.Parameters.AddWithValue("@telefon", txtTelefon.Text);
                komut.Parameters.AddWithValue("@barkodNo", txtBarkodNo.Text);
                komut.Parameters.AddWithValue("@urunAdi", txt�r�nAd�.Text);
                komut.Parameters.AddWithValue("@miktari", int.Parse(txtMiktar�.Text));
                komut.Parameters.AddWithValue("@satisFiyati", double.Parse(txtSat��Fiyat�.Text));
                komut.Parameters.AddWithValue("@toplamFiyat", double.Parse(txtToplamFiyat�.Text));
                komut.Parameters.AddWithValue("@tarih", DateTime.Now.ToString());
                komut.ExecuteNonQuery();
                baglanti.Close();
            }
            else
            {
                baglanti.Open();
                SqlCommand komut2 = new SqlCommand("update sepet set miktari=miktari+'"+int.Parse(txtMiktar�.Text)+ "'where barkodNo='" + txtBarkodNo.Text + "'", baglanti);
                komut2.ExecuteNonQuery();
                SqlCommand komut3 = new SqlCommand("update sepet set toplamFiyat=miktari*satisFiyati where barkodNo='" + txtBarkodNo.Text + "'", baglanti);
                komut3.ExecuteNonQuery();
                baglanti.Close();
            }
            
            txtMiktar�.Text = "1";
            daset.Tables["sepet"].Clear();
            sepetlistele();
            hesapla();
            foreach (Control item in groupBox2.Controls)
            {
                if (item is TextBox)
                {
                    if (item != txtMiktar�)
                    {
                        item.Text = "";
                    }
                }
            }
        }

        private void txtMiktar�_TextChanged(object sender, EventArgs e)
        {
            try
            {
                txtToplamFiyat�.Text = (double.Parse(txtMiktar�.Text) * double.Parse(txtSat��Fiyat�.Text)).ToString(); 
            }
            catch(Exception)
            {
                ;
            }
        }

        private void txtToplamFiyat�_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtSat��Fiyat�_TextChanged(object sender, EventArgs e)
        {
            try
            {
                txtToplamFiyat�.Text = (double.Parse(txtMiktar�.Text) * double.Parse(txtSat��Fiyat�.Text)).ToString();
            }
            catch (Exception)
            {
                ;
            }
        }

        private void btnSil_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            SqlCommand komut = new SqlCommand("delete from sepet where barkodNo='"+dataGridView1.CurrentRow.Cells["barkodNo"].Value.ToString()+"'", baglanti);
            komut.ExecuteNonQuery();
            baglanti.Close();
           
            MessageBox.Show("�r�n sepetten silindi");
            daset.Tables["sepet"].Clear();
            sepetlistele();
            hesapla();
        }

        private void btnSat���ptal_Click(object sender, EventArgs e)
        {

            baglanti.Open();
            SqlCommand komut = new SqlCommand("delete from sepet", baglanti);
            komut.ExecuteNonQuery();
            baglanti.Close();
            MessageBox.Show("�r�nler sepetten silindi");
            daset.Tables["sepet"].Clear();
            sepetlistele();
            hesapla();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            FrmSatisListele listele = new FrmSatisListele();
            listele.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FrmGiderler listele = new FrmGiderler();
            listele.ShowDialog();
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            FrmGiderListelecs listele = new FrmGiderListelecs();
            listele.ShowDialog();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            FrmTedarik�iEkle listele = new FrmTedarik�iEkle();
            listele.ShowDialog();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            FrmTedarikciListele listele = new FrmTedarikciListele();
            listele.ShowDialog();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            FrmSiparisEt listele = new FrmSiparisEt();
            listele.ShowDialog();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            FrmGelirGider listele = new FrmGelirGider();
            listele.ShowDialog();
        }
        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void button14_Click(object sender, EventArgs e)
        {
            FrmSiparisListelecs listele = new FrmSiparisListelecs();
            listele.ShowDialog();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            FrmDepo listele = new FrmDepo();
            listele.ShowDialog();
        }
    }
}