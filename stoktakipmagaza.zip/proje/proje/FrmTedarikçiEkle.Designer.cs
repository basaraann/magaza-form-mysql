﻿namespace proje
{
    partial class FrmTedarikçiEkle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtNumara = new System.Windows.Forms.TextBox();
            this.txtTedarikçiAdi = new System.Windows.Forms.TextBox();
            this.txtTedarikçiTelefon = new System.Windows.Forms.TextBox();
            this.txtTedarikçiAdresi = new System.Windows.Forms.TextBox();
            this.txtTedarikçiEmail = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtNumara
            // 
            this.txtNumara.Location = new System.Drawing.Point(342, 80);
            this.txtNumara.Name = "txtNumara";
            this.txtNumara.Size = new System.Drawing.Size(125, 27);
            this.txtNumara.TabIndex = 0;
            this.txtNumara.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txtTedarikçiAdi
            // 
            this.txtTedarikçiAdi.Location = new System.Drawing.Point(342, 146);
            this.txtTedarikçiAdi.Name = "txtTedarikçiAdi";
            this.txtTedarikçiAdi.Size = new System.Drawing.Size(125, 27);
            this.txtTedarikçiAdi.TabIndex = 1;
            // 
            // txtTedarikçiTelefon
            // 
            this.txtTedarikçiTelefon.Location = new System.Drawing.Point(342, 214);
            this.txtTedarikçiTelefon.Name = "txtTedarikçiTelefon";
            this.txtTedarikçiTelefon.Size = new System.Drawing.Size(125, 27);
            this.txtTedarikçiTelefon.TabIndex = 2;
            // 
            // txtTedarikçiAdresi
            // 
            this.txtTedarikçiAdresi.Location = new System.Drawing.Point(342, 277);
            this.txtTedarikçiAdresi.Name = "txtTedarikçiAdresi";
            this.txtTedarikçiAdresi.Size = new System.Drawing.Size(125, 27);
            this.txtTedarikçiAdresi.TabIndex = 3;
            // 
            // txtTedarikçiEmail
            // 
            this.txtTedarikçiEmail.Location = new System.Drawing.Point(342, 338);
            this.txtTedarikçiEmail.Name = "txtTedarikçiEmail";
            this.txtTedarikçiEmail.Size = new System.Drawing.Size(125, 27);
            this.txtTedarikçiEmail.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(166, 80);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(135, 20);
            this.label1.TabIndex = 5;
            this.label1.Text = "Tedarikçi Numarası";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(166, 146);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(95, 20);
            this.label2.TabIndex = 6;
            this.label2.Text = "Tedarikçi Adı";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(166, 214);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(129, 20);
            this.label3.TabIndex = 7;
            this.label3.Text = "Tedarikçi Telefonu";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(166, 277);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(114, 20);
            this.label4.TabIndex = 8;
            this.label4.Text = "Tedarikçi Adresi";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(166, 338);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(115, 20);
            this.label5.TabIndex = 9;
            this.label5.Text = "Tedarikçi E-mail";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(610, 191);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(94, 29);
            this.button1.TabIndex = 10;
            this.button1.Text = "Ekle";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // FrmTedarikçiEkle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtTedarikçiEmail);
            this.Controls.Add(this.txtTedarikçiAdresi);
            this.Controls.Add(this.txtTedarikçiTelefon);
            this.Controls.Add(this.txtTedarikçiAdi);
            this.Controls.Add(this.txtNumara);
            this.Name = "FrmTedarikçiEkle";
            this.Text = "FrmTedarikçiEkle";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TextBox txtNumara;
        private TextBox txtTedarikçiAdi;
        private TextBox txtTedarikçiTelefon;
        private TextBox txtTedarikçiAdresi;
        private TextBox txtTedarikçiEmail;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Button button1;
    }
}