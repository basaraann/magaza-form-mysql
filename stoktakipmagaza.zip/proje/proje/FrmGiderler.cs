﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace proje
{
    public partial class FrmGiderler : Form
    {
        public FrmGiderler()
        {
            InitializeComponent();
        }
        SqlConnection baglanti = new SqlConnection("Data Source=DESKTOP-7QP2GE5;Initial Catalog=Stok_Takip;Integrated Security=True");

        private void btnEkleGider_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            SqlCommand komut = new SqlCommand("insert into gider(eleman,cay,elektrik,yemek,ısıtma) values(@eleman,@cay,@elektrik,@yemek,@ısıtma)", baglanti);       
            komut.Parameters.AddWithValue("@eleman", double.Parse(txtEleman.Text));
            komut.Parameters.AddWithValue("@cay", double.Parse(txtCay.Text));
            komut.Parameters.AddWithValue("@elektrik", double.Parse(txtElektrik.Text));
            komut.Parameters.AddWithValue("@yemek", double.Parse(txtYemek.Text));
            komut.Parameters.AddWithValue("@ısıtma", double.Parse(txtisitma.Text));
           
            komut.ExecuteNonQuery();
            baglanti.Close();
            MessageBox.Show("Giderler eklendi");
          


        }

        private void button1_Click(object sender, EventArgs e)
        {
           
        }
    }
}
