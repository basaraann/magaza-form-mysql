﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace proje
{
    public partial class FrmSiparisEt : Form
    {
        public FrmSiparisEt()
        {
            InitializeComponent();
        }
        SqlConnection baglanti = new SqlConnection("Data Source=DESKTOP-7QP2GE5;Initial Catalog=Stok_Takip;Integrated Security=True");
        private void SiparisGetir()
        {
            baglanti.Open();
            SqlCommand komut = new SqlCommand("select *from tedarikci", baglanti);
            SqlDataReader read = komut.ExecuteReader();
            while (read.Read())
            {
                comboBox1.Items.Add(read["tedarikciNo"].ToString());
               
            }
            baglanti.Close();
        }
       
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
            baglanti.Open();
            SqlCommand komut = new SqlCommand("select *from tedarikci where tedarikciNo like '" + comboBox1.Text + "'", baglanti);
            SqlDataReader read = komut.ExecuteReader();
            while (read.Read())
            {
                textBox1.Text = read["tedarikciAdı"].ToString();
                textBox2.Text = read["tedarikciTel"].ToString();
            }
            baglanti.Close();
        }
        
        
        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
        bool durum;
        private void barkodkontrol()
        {
            durum = true;
            baglanti.Open();
            SqlCommand komut = new SqlCommand("select *from urun", baglanti);
            SqlDataReader read = komut.ExecuteReader();
            while (read.Read())
            {
                if (txtBarkodSiparis.Text == read["barkodNo"].ToString() || txtBarkodSiparis.Text == "")
                {
                    durum = false;
                }
            }
            baglanti.Close();
        }
        private void button1_Click(object sender, EventArgs e)
        {

                baglanti.Open();
                SqlCommand komut = new SqlCommand("insert into siparis(tedarikciNo,tedarikciAdi,tedarikciTelefonu,barkodNo,urunAdi,miktari,alisFiyati,tarih) values(@tedarikciNo,@tedarikciAdi,@tedarikciTelefonu,@barkodNo,@urunAdi,@miktari,@alisFiyati,@tarih)", baglanti);
                komut.Parameters.AddWithValue("@tedarikciNo", comboBox1.Text);
                komut.Parameters.AddWithValue("@tedarikciAdi", textBox1.Text);
                komut.Parameters.AddWithValue("@tedarikciTelefonu", textBox2.Text);
                komut.Parameters.AddWithValue("@barkodNo", txtBarkodSiparis.Text);
                komut.Parameters.AddWithValue("@miktari", int.Parse(textBox4.Text));
                komut.Parameters.AddWithValue("@alisFiyati", double.Parse(textBox5.Text));
                komut.Parameters.AddWithValue("@urunAdi", textBox3.Text);
                komut.Parameters.AddWithValue("@tarih", DateTime.Now.ToString());
                komut.ExecuteNonQuery();
                
                MessageBox.Show("siparis eklendi");
                SqlCommand komut2 = new SqlCommand("update urun set miktari=miktari+'" + int.Parse(textBox4.Text) + "' where barkodno='" + txtBarkodSiparis.Text + "'", baglanti);
                komut2.ExecuteNonQuery();
            baglanti.Close();
        }
       
    private void FrmSiparisEt_Load(object sender, EventArgs e)
        {
   
            SiparisGetir();         
        }

        private void txtBarkodSiparis_TextChanged(object sender, EventArgs e)
        {
            if (txtBarkodSiparis.Text != "")
            {
                baglanti.Open();
                SqlCommand komut = new SqlCommand("select *from urun where barkodNo like '" + txtBarkodSiparis.Text + "'", baglanti);
                SqlDataReader read = komut.ExecuteReader();
                while (read.Read())
                {
                    textBox3.Text = read["urunAdi"].ToString();
                    textBox5.Text = read["alisFiyati"].ToString();
                }
                baglanti.Close();
            }
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
