﻿/****************************************************************************
**					SAKARYA ÜNİVERSİTESİ
**				BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				    BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				   NESNEYE DAYALI PROGRAMLAMA DERSİ
**					2014-2015 BAHAR DÖNEMİ
**	
**				ÖDEV NUMARASI..........:Proje
**				ÖĞRENCİ ADI............:Buğra Başaran
**				ÖĞRENCİ NUMARASI.......:g211210015
**                         DERSİN ALINDIĞI GRUP...:
****************************************************************************/


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace proje
{
    public partial class FrmGelirGider : Form
    {
       
        public FrmGelirGider()
        {
            InitializeComponent();
        }
        SqlConnection baglanti = new SqlConnection("Data Source=DESKTOP-7QP2GE5;Initial Catalog=Stok_Takip;Integrated Security=True");
        DataSet daset = new DataSet();
        private void siparislistele()
        {
            baglanti.Open();
            SqlDataAdapter adtr = new SqlDataAdapter("select *from siparis", baglanti);
            adtr.Fill(daset, "siparis");
            dataGridView1.DataSource = daset.Tables["siparis"];
            baglanti.Close();
            
        }
        private void Gelirlistele()
        {
            baglanti.Open();
            SqlDataAdapter adtr = new SqlDataAdapter("select *from satis", baglanti);
            adtr.Fill(daset, "satis");
            dataGridView2.DataSource = daset.Tables["satis"];
            baglanti.Close();
        }
        private void Masraflistele()
        {
            baglanti.Open();
            SqlDataAdapter adtr = new SqlDataAdapter("select *from gider", baglanti);
            adtr.Fill(daset, "gider");
            dataGridView3.DataSource = daset.Tables["gider"];
            baglanti.Close();
        }
        private void hesaplaMasraf()
        {    
            try
            {
                baglanti.Open();
                SqlCommand komut = new SqlCommand("select sum(eleman)+sum(cay)+sum(elektrik)+sum(yemek)+sum(ısıtma) from gider", baglanti);
                lblmasraflar.Text = komut.ExecuteScalar() + "TL";      
                
                baglanti.Close();          
            }
            catch (Exception)
            {
                ;
            }
        }
        private void siparisGiderHesapla()
        {
            try
            {
                baglanti.Open();
                SqlCommand komut = new SqlCommand("select sum(alisFiyati*miktari) from siparis", baglanti);
                siparisToplam.Text = komut.ExecuteScalar() + "TL";
                baglanti.Close();        
            }
            catch (Exception)
            {
                ;
            }
        }
        private void siparisGelirHesapla()
        {
            try
            {
                baglanti.Open();
                SqlCommand komut = new SqlCommand("select sum(toplamFiyat) from satis", baglanti);
                siparisGelir.Text = komut.ExecuteScalar() + "TL";
                baglanti.Close();
             
            }
            catch (Exception)
            {
                ;
            }
        }
        
        private void dataGridView2_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }
        private void karZarar()
        {
            double sonuc = 0;
            baglanti.Open();
            SqlCommand komut = new SqlCommand("select sum(alisFiyati*miktari) from siparis", baglanti);
            siparisToplam.Text = komut.ExecuteScalar() + "";
            //
            SqlCommand komut1 = new SqlCommand("select sum(eleman)+sum(cay)+sum(elektrik)+sum(yemek)+sum(ısıtma) from gider", baglanti);
            lblmasraflar.Text = komut1.ExecuteScalar() + "";
            //
            SqlCommand komut2 = new SqlCommand("select sum(toplamFiyat) from satis", baglanti);
            siparisGelir.Text = komut2.ExecuteScalar() + "";
            //
            if (siparisGelir.Text != "" && lblmasraflar.Text != "" && siparisToplam.Text != "")
            {
                sonuc = double.Parse(siparisGelir.Text) - double.Parse(lblmasraflar.Text) - double.Parse(siparisToplam.Text);
                if (sonuc > 0)
                {
                    lblkarzarar.Text = sonuc.ToString() + "  TL kar elde ettiniz.";
                }
                else if (sonuc == 0)
                {
                    lblkarzarar.Text = "  ne kar ne zarar ettiniz.";
                }
                else
                {
                    lblkarzarar.Text = sonuc.ToString() + "  TL zarar elde ettiniz.";
                }
            }
            else
            {
                MessageBox.Show("lütfen tüm gelir ve giderleri girdiğinizden emin olun.");
            }
            SqlCommand komut3 = new SqlCommand("select sum(alisFiyati*miktari) from siparis", baglanti);
            siparisToplam.Text = komut3.ExecuteScalar() + "TL";
            //
            SqlCommand komut4 = new SqlCommand("select sum(eleman)+sum(cay)+sum(elektrik)+sum(yemek)+sum(ısıtma) from gider", baglanti);
            lblmasraflar.Text = komut4.ExecuteScalar() + "TL";
            //
            SqlCommand komut5 = new SqlCommand("select sum(toplamFiyat) from satis", baglanti);
            siparisGelir.Text = komut5.ExecuteScalar() + "TL";
            baglanti.Close();
        }
        private void FrmGelirGider_Load(object sender, EventArgs e)
        {
            siparislistele();
            siparisGiderHesapla();
            Gelirlistele();
            siparisGelirHesapla();
            hesaplaMasraf();
            Masraflistele();
            karZarar();   
        }
    }
}
