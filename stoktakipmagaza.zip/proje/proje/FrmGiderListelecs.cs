﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace proje
{
    public partial class FrmGiderListelecs : Form
    {
        public FrmGiderListelecs()
        {
            InitializeComponent();
        }
        SqlConnection baglanti = new SqlConnection("Data Source=DESKTOP-7QP2GE5;Initial Catalog=Stok_Takip;Integrated Security=True");
        DataSet daset = new DataSet();
        private void giderlistele()
        {
            baglanti.Open();
            SqlDataAdapter adtr = new SqlDataAdapter("select *from gider", baglanti);
            adtr.Fill(daset, "gider");
            dataGridView1.DataSource = daset.Tables["gider"];

            baglanti.Close();
        }
        private void hesaplaGider()
        {
            try
            {
                baglanti.Open();
                SqlCommand komut = new SqlCommand("select sum(eleman)+sum(cay)+sum(elektrik)+sum(yemek)+sum(ısıtma) from gider", baglanti);
                lblGiderToplam.Text = komut.ExecuteScalar() + "TL";
                baglanti.Close();
            }
            catch (Exception)
            {
                ;
            }
        }
        private void FrmGiderListelecs_Load(object sender, EventArgs e)
        {
            giderlistele();
            hesaplaGider();
        }
        private void Gider_Göster()
        {
            baglanti.Open();
            SqlDataAdapter adtr = new SqlDataAdapter("select *from gider", baglanti);
            adtr.Fill(daset, "gider");
            dataGridView1.DataSource = daset.Tables["gider"];
            baglanti.Close();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            SqlCommand komut = new SqlCommand("delete from gider", baglanti);
            komut.ExecuteNonQuery();//onaylama
            baglanti.Close();
            daset.Tables["gider"].Clear();
            Gider_Göster();
            MessageBox.Show("kayıt silindi");
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
