﻿namespace proje
{
    partial class FrmTedarikciListele
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtTedarikçiEmail = new System.Windows.Forms.TextBox();
            this.txtTedarikçiAdresi = new System.Windows.Forms.TextBox();
            this.txtTedarikçiTelefon = new System.Windows.Forms.TextBox();
            this.txtTedarikçiAdi = new System.Windows.Forms.TextBox();
            this.txtNumara = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnSil = new System.Windows.Forms.Button();
            this.btnGüncelle = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.txtTedarikciAra = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(23, 326);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(115, 20);
            this.label5.TabIndex = 19;
            this.label5.Text = "Tedarikçi E-mail";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(23, 265);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(114, 20);
            this.label4.TabIndex = 18;
            this.label4.Text = "Tedarikçi Adresi";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(23, 202);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(129, 20);
            this.label3.TabIndex = 17;
            this.label3.Text = "Tedarikçi Telefonu";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(23, 134);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(95, 20);
            this.label2.TabIndex = 16;
            this.label2.Text = "Tedarikçi Adı";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(23, 68);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(135, 20);
            this.label1.TabIndex = 15;
            this.label1.Text = "Tedarikçi Numarası";
            // 
            // txtTedarikçiEmail
            // 
            this.txtTedarikçiEmail.Location = new System.Drawing.Point(158, 326);
            this.txtTedarikçiEmail.Name = "txtTedarikçiEmail";
            this.txtTedarikçiEmail.Size = new System.Drawing.Size(125, 27);
            this.txtTedarikçiEmail.TabIndex = 14;
            // 
            // txtTedarikçiAdresi
            // 
            this.txtTedarikçiAdresi.Location = new System.Drawing.Point(158, 265);
            this.txtTedarikçiAdresi.Name = "txtTedarikçiAdresi";
            this.txtTedarikçiAdresi.Size = new System.Drawing.Size(125, 27);
            this.txtTedarikçiAdresi.TabIndex = 13;
            // 
            // txtTedarikçiTelefon
            // 
            this.txtTedarikçiTelefon.Location = new System.Drawing.Point(158, 202);
            this.txtTedarikçiTelefon.Name = "txtTedarikçiTelefon";
            this.txtTedarikçiTelefon.Size = new System.Drawing.Size(125, 27);
            this.txtTedarikçiTelefon.TabIndex = 12;
            // 
            // txtTedarikçiAdi
            // 
            this.txtTedarikçiAdi.Location = new System.Drawing.Point(158, 134);
            this.txtTedarikçiAdi.Name = "txtTedarikçiAdi";
            this.txtTedarikçiAdi.Size = new System.Drawing.Size(125, 27);
            this.txtTedarikçiAdi.TabIndex = 11;
            // 
            // txtNumara
            // 
            this.txtNumara.Location = new System.Drawing.Point(158, 68);
            this.txtNumara.Name = "txtNumara";
            this.txtNumara.Size = new System.Drawing.Size(125, 27);
            this.txtNumara.TabIndex = 10;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(321, 70);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 29;
            this.dataGridView1.Size = new System.Drawing.Size(467, 302);
            this.dataGridView1.TabIndex = 20;
            this.dataGridView1.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellDoubleClick);
            // 
            // btnSil
            // 
            this.btnSil.Location = new System.Drawing.Point(519, 380);
            this.btnSil.Name = "btnSil";
            this.btnSil.Size = new System.Drawing.Size(94, 29);
            this.btnSil.TabIndex = 25;
            this.btnSil.Text = "silme";
            this.btnSil.UseVisualStyleBackColor = true;
            this.btnSil.Click += new System.EventHandler(this.btnSil_Click);
            // 
            // btnGüncelle
            // 
            this.btnGüncelle.Location = new System.Drawing.Point(368, 380);
            this.btnGüncelle.Name = "btnGüncelle";
            this.btnGüncelle.Size = new System.Drawing.Size(94, 29);
            this.btnGüncelle.TabIndex = 24;
            this.btnGüncelle.Text = "güncelle";
            this.btnGüncelle.UseVisualStyleBackColor = true;
            this.btnGüncelle.Click += new System.EventHandler(this.btnGüncelle_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(335, 40);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(162, 20);
            this.label6.TabIndex = 27;
            this.label6.Text = "Tedarikçi Numarası Ara";
            // 
            // txtTedarikciAra
            // 
            this.txtTedarikciAra.Location = new System.Drawing.Point(523, 37);
            this.txtTedarikciAra.Name = "txtTedarikciAra";
            this.txtTedarikciAra.Size = new System.Drawing.Size(125, 27);
            this.txtTedarikciAra.TabIndex = 26;
            this.txtTedarikciAra.TextChanged += new System.EventHandler(this.txtTedarikciAra_TextChanged);
            // 
            // FrmTedarikciListele
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtTedarikciAra);
            this.Controls.Add(this.btnSil);
            this.Controls.Add(this.btnGüncelle);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtTedarikçiEmail);
            this.Controls.Add(this.txtTedarikçiAdresi);
            this.Controls.Add(this.txtTedarikçiTelefon);
            this.Controls.Add(this.txtTedarikçiAdi);
            this.Controls.Add(this.txtNumara);
            this.Name = "FrmTedarikciListele";
            this.Text = "FrmTedarikciListele";
            this.Load += new System.EventHandler(this.FrmTedarikciListele_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox txtTedarikçiEmail;
        private TextBox txtTedarikçiAdresi;
        private TextBox txtTedarikçiTelefon;
        private TextBox txtTedarikçiAdi;
        private TextBox txtNumara;
        private DataGridView dataGridView1;
        private Button btnSil;
        private Button btnGüncelle;
        private Label label6;
        private TextBox txtTedarikciAra;
    }
}