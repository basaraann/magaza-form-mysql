﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace proje
{
    public partial class FrmÜrünEkle : Form
    {
        public FrmÜrünEkle()
        {
            InitializeComponent();
        }
        SqlConnection baglanti = new SqlConnection("Data Source=DESKTOP-7QP2GE5;Initial Catalog=Stok_Takip;Integrated Security=True");
        bool durum;
        private void barkodkontrol()
        {
            durum = true;
            baglanti.Open();
            SqlCommand komut = new SqlCommand("select *from urun", baglanti);
            SqlDataReader read = komut.ExecuteReader();
            while (read.Read())
            {
                if (txtBarkodNo.Text == read["barkodNo"].ToString()|| txtBarkodNo.Text=="")
                {
                    durum = false;
                }
            }
            baglanti.Close();
        }
        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }
        private void kategoriGetir()
        {
            baglanti.Open();
            SqlCommand komut = new SqlCommand("select *from kategoribilgileri", baglanti);
            SqlDataReader read = komut.ExecuteReader();
            while (read.Read())
            {
                comboKategori.Items.Add(read["kategori"].ToString());
            }
            baglanti.Close();
        }
            private void FrmÜrünEkle_Load(object sender, EventArgs e)
            {
            kategoriGetir();
            comboBox1.Items.Add("Depo");
            comboBox1.Items.Add("Raf");       
            }

        private void comboKategori_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboMarka.Items.Clear();
            comboMarka.Text = "";
            baglanti.Open();
            SqlCommand komut = new SqlCommand("select *from markabilgileri where kategori='"+comboKategori.SelectedItem+"'", baglanti);
            SqlDataReader read = komut.ExecuteReader();
            while (read.Read())
            {
                comboMarka.Items.Add(read["marka"].ToString());
            }
            baglanti.Close();
        }

        private void comboMarka_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void btnYeniEkle_Click(object sender, EventArgs e)
        {
            barkodkontrol();
            if (durum == true)
            {
                baglanti.Open();
                SqlCommand komut = new SqlCommand("insert into urun(barkodNo,kategori,marka,urunAdi,miktari,alisFiyati,satisFiyati,tarih,yer) values(@barkodNo, @kategori, @marka, @urunAdi, @miktari, @alisFiyati, @satisFiyati, @tarih,@yer)", baglanti);
                komut.Parameters.AddWithValue("@barkodNo", txtBarkodNo.Text);
                komut.Parameters.AddWithValue("@kategori", comboKategori.Text);
                komut.Parameters.AddWithValue("@marka", comboMarka.Text);
                komut.Parameters.AddWithValue("@urunAdi", txtUrunAdi.Text);
                komut.Parameters.AddWithValue("@miktari", int.Parse(txtMiktari.Text));
                komut.Parameters.AddWithValue("@alisFiyati", double.Parse(txtAlisFiyati.Text));
                komut.Parameters.AddWithValue("@satisFiyati", double.Parse(txtSatisFiyati.Text));
                komut.Parameters.AddWithValue("@tarih", DateTime.Now.ToString());
                komut.Parameters.AddWithValue("@yer", comboBox1.Text);
                komut.ExecuteNonQuery();
                baglanti.Close();
                MessageBox.Show("ürün eklendi");
            }
            else
            {
                MessageBox.Show("Böyle bir barkodNo var", "!!!");
            }
                comboMarka.Items.Clear();
                foreach (Control İtem in groupBox1.Controls)
                {
                    if (İtem is TextBox)
                    {
                        İtem.Text = "";
                    }
                    if (İtem is ComboBox)
                    {
                        İtem.Text = "";
                    }
                }
        }

        private void btnVarOlanaEkle_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            SqlCommand komut = new SqlCommand("update urun set miktari=miktari+'"+int.Parse(Miktaritxt.Text)+"' where barkodNo='"+BarkodNotxt.Text+"'",baglanti);
            komut.ExecuteNonQuery();
            baglanti.Close();
            foreach (Control İtem in groupBox1.Controls)
            {
                if (İtem is TextBox)
                {
                    İtem.Text = "";
                }
                if (İtem is ComboBox)
                {
                    İtem.Text = "";
                }
            }
            MessageBox.Show("Var olan ürüne ekleme yapıldı");
        }
        private void BarkodNotxt_TextChanged(object sender, EventArgs e)
        {
            if(BarkodNotxt.Text=="")
            {
                lblMiktari.Text = "";
                foreach(Control İtem in groupBox2.Controls)
                {
                    if(İtem is TextBox)
                    {
                        İtem.Text = "";
                    }
                }
            }
            baglanti.Open();
            SqlCommand komut1 = new SqlCommand("select *from urun where barkodNo like '" + BarkodNotxt.Text+"'", baglanti);
            SqlDataReader read = komut1.ExecuteReader();
            while(read.Read())
            {
                Kategoritxt.Text = read["kategori"].ToString();
                Markatxt.Text = read["marka"].ToString();
                UrunAditxt.Text = read["urunAdi"].ToString();
                lblMiktari.Text = read["miktari"].ToString();
                AlisFiyatitxt.Text = read["alisFiyati"].ToString();
                SatisFiyatitxt.Text = read["satisFiyati"].ToString();
                comboBox2.Text = read["yer"].ToString();
            }
            baglanti.Close();
        }
    }
}
  