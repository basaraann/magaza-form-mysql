﻿/****************************************************************************
**					SAKARYA ÜNİVERSİTESİ
**				BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				    BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				   NESNEYE DAYALI PROGRAMLAMA DERSİ
**					2014-2015 BAHAR DÖNEMİ
**	
**				ÖDEV NUMARASI..........:Proje
**				ÖĞRENCİ ADI............:Buğra Başaran
**				ÖĞRENCİ NUMARASI.......:g211210015
**                         DERSİN ALINDIĞI GRUP...:
****************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace proje
{
    public partial class FrmSiparisListelecs : Form
    {
        public FrmSiparisListelecs()
        {
            InitializeComponent();
        }
        SqlConnection baglanti = new SqlConnection("Data Source=DESKTOP-7QP2GE5;Initial Catalog=Stok_Takip;Integrated Security=True");
        DataSet daset = new DataSet();
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void Siparis_Listele()
        {
            baglanti.Open();
            SqlDataAdapter adtr = new SqlDataAdapter("select *from siparis", baglanti);
            adtr.Fill(daset, "siparis");
            dataGridView1.DataSource = daset.Tables["siparis"];
            baglanti.Close();
        }

        private void FrmSiparisListelecs_Load(object sender, EventArgs e)
        {
            Siparis_Listele();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            SqlCommand komut = new SqlCommand("delete from siparis", baglanti);
            komut.ExecuteNonQuery();//onaylama
            baglanti.Close();
            daset.Tables["siparis"].Clear();
            Siparis_Listele();
            MessageBox.Show("Sipariş silindi");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            SqlCommand komut = new SqlCommand("delete from siparis where tedarikciNo='" + dataGridView1.CurrentRow.Cells["tedarikciNo"].Value.ToString() + "'", baglanti);
            komut.ExecuteNonQuery();
            baglanti.Close();
            MessageBox.Show("sipariş sepetten silindi");
            daset.Tables["siparis"].Clear();
            Siparis_Listele();
        }
    }
}
