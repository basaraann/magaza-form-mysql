﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace proje
{
    public partial class FrmTedarikciListele : Form
    {
        public FrmTedarikciListele()
        {
            InitializeComponent();
        }
        SqlConnection baglanti = new SqlConnection("Data Source=DESKTOP-7QP2GE5;Initial Catalog=Stok_Takip;Integrated Security=True");
        DataSet daset = new DataSet();
        private void tedarikci_Göster()
        {
            baglanti.Open();
            SqlDataAdapter adtr = new SqlDataAdapter("select *from tedarikci", baglanti);
            adtr.Fill(daset, "tedarikci");
            dataGridView1.DataSource = daset.Tables["tedarikci"];
            baglanti.Close();
        }
        private void btnGüncelle_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            SqlCommand komut = new SqlCommand("update tedarikci set tedarikciAdı=@tedarikciAdı,tedarikciTel=@tedarikciTel,tedarikciAdresi=@tedarikciAdresi,tedarikciEmail=@tedarikciEmail where tedarikciNo=@tedarikciNo", baglanti);
            komut.Parameters.AddWithValue("@tedarikciNo", txtNumara.Text);
            komut.Parameters.AddWithValue("@tedarikciAdı", txtTedarikçiAdi.Text);
            komut.Parameters.AddWithValue("@tedarikciTel", txtTedarikçiTelefon.Text);
            komut.Parameters.AddWithValue("@tedarikciAdresi", txtTedarikçiAdresi.Text);
            komut.Parameters.AddWithValue("@tedarikciEmail", txtTedarikçiEmail.Text);
            komut.ExecuteNonQuery();
            baglanti.Close();
            daset.Tables["tedarikci"].Clear();
            tedarikci_Göster();
            MessageBox.Show("Tedarikçi kaydı güncellendi");
            foreach (Control item in this.Controls)
            {
                if (item is TextBox)
                {
                    item.Text = "";
                }
            }
        }

        private void FrmTedarikciListele_Load(object sender, EventArgs e)
        {
            tedarikci_Göster();
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            
                txtNumara.Text = dataGridView1.CurrentRow.Cells["tedarikciNo"].Value.ToString();
                txtTedarikçiAdi.Text = dataGridView1.CurrentRow.Cells["tedarikciAdı"].Value.ToString();
                txtTedarikçiTelefon.Text = dataGridView1.CurrentRow.Cells["tedarikciTel"].Value.ToString();
                txtTedarikçiAdresi.Text = dataGridView1.CurrentRow.Cells["tedarikciAdresi"].Value.ToString();
                txtTedarikçiEmail.Text = dataGridView1.CurrentRow.Cells["tedarikciEmail"].Value.ToString();
            
        }

        private void btnSil_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            SqlCommand komut = new SqlCommand("delete from tedarikci where tedarikciNo='" + dataGridView1.CurrentRow.Cells["tedarikciNo"].Value.ToString() + "'", baglanti);
            komut.ExecuteNonQuery();//onaylama
            baglanti.Close();
            daset.Tables["tedarikci"].Clear();
            tedarikci_Göster();
            MessageBox.Show("tedarikci silindi");
        }

        private void txtTedarikciAra_TextChanged(object sender, EventArgs e)
        {
            DataTable tablo = new DataTable();
            baglanti.Open();
            SqlDataAdapter adtr = new SqlDataAdapter("select *from tedarikci where tedarikciNo like '%" + txtTedarikciAra.Text + "'", baglanti);
            adtr.Fill(tablo);
            dataGridView1.DataSource = tablo;
            baglanti.Close();

        }
    }
}
