﻿namespace proje
{
    partial class FrmGiderler
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtEleman = new System.Windows.Forms.TextBox();
            this.lbleleman = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtCay = new System.Windows.Forms.TextBox();
            this.txtElektrik = new System.Windows.Forms.TextBox();
            this.txtYemek = new System.Windows.Forms.TextBox();
            this.txtisitma = new System.Windows.Forms.TextBox();
            this.btnEkleGider = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtEleman
            // 
            this.txtEleman.Location = new System.Drawing.Point(130, 74);
            this.txtEleman.Name = "txtEleman";
            this.txtEleman.Size = new System.Drawing.Size(125, 27);
            this.txtEleman.TabIndex = 0;
            // 
            // lbleleman
            // 
            this.lbleleman.AutoSize = true;
            this.lbleleman.Location = new System.Drawing.Point(20, 77);
            this.lbleleman.Name = "lbleleman";
            this.lbleleman.Size = new System.Drawing.Size(111, 20);
            this.lbleleman.TabIndex = 1;
            this.lbleleman.Text = "Eleman Masrafı";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(20, 125);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Çay Masrafı";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(20, 173);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(110, 20);
            this.label3.TabIndex = 3;
            this.label3.Text = "Elektrik Masrafı";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(20, 220);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(105, 20);
            this.label4.TabIndex = 4;
            this.label4.Text = "Yemek Masrafı";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(20, 264);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(102, 20);
            this.label5.TabIndex = 5;
            this.label5.Text = "Isıtma Masrafı";
            // 
            // txtCay
            // 
            this.txtCay.Location = new System.Drawing.Point(130, 122);
            this.txtCay.Name = "txtCay";
            this.txtCay.Size = new System.Drawing.Size(125, 27);
            this.txtCay.TabIndex = 6;
            // 
            // txtElektrik
            // 
            this.txtElektrik.Location = new System.Drawing.Point(130, 166);
            this.txtElektrik.Name = "txtElektrik";
            this.txtElektrik.Size = new System.Drawing.Size(125, 27);
            this.txtElektrik.TabIndex = 7;
            // 
            // txtYemek
            // 
            this.txtYemek.Location = new System.Drawing.Point(130, 213);
            this.txtYemek.Name = "txtYemek";
            this.txtYemek.Size = new System.Drawing.Size(125, 27);
            this.txtYemek.TabIndex = 8;
            // 
            // txtisitma
            // 
            this.txtisitma.Location = new System.Drawing.Point(130, 257);
            this.txtisitma.Name = "txtisitma";
            this.txtisitma.Size = new System.Drawing.Size(125, 27);
            this.txtisitma.TabIndex = 9;
            // 
            // btnEkleGider
            // 
            this.btnEkleGider.Location = new System.Drawing.Point(226, 290);
            this.btnEkleGider.Name = "btnEkleGider";
            this.btnEkleGider.Size = new System.Drawing.Size(94, 29);
            this.btnEkleGider.TabIndex = 10;
            this.btnEkleGider.Text = "Ekle";
            this.btnEkleGider.UseVisualStyleBackColor = true;
            this.btnEkleGider.Click += new System.EventHandler(this.btnEkleGider_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lbleleman);
            this.groupBox1.Controls.Add(this.btnEkleGider);
            this.groupBox1.Controls.Add(this.txtEleman);
            this.groupBox1.Controls.Add(this.txtisitma);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtYemek);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtElektrik);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txtCay);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Location = new System.Drawing.Point(210, 55);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(335, 334);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Gider Ekle";
            // 
            // FrmGiderler
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.HotTrack;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox1);
            this.Name = "FrmGiderler";
            this.Text = "Giderler";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private TextBox txtEleman;
        private Label lbleleman;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private TextBox txtCay;
        private TextBox txtElektrik;
        private TextBox txtYemek;
        private TextBox txtisitma;
        private Button btnEkleGider;
        private GroupBox groupBox1;
    }
}