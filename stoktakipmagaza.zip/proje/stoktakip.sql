USE [master]
GO

/****** Object:  Database [Stok_Takip]    Script Date: 3.01.2023 19:40:03 ******/
DROP DATABASE [Stok_Takip]
GO

